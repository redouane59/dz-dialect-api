package function;

import com.google.cloud.functions.HttpFunction;
import com.google.cloud.functions.HttpRequest;
import com.google.cloud.functions.HttpResponse;
import function.helper.Config;
import function.model.Sentence;
import function.model.generator.SentenceGenerator;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SentenceGeneratorAPI implements HttpFunction {

  @Override
  public void service(final HttpRequest httpRequest, final HttpResponse httpResponse) throws IOException {
    LOGGER.debug("service called");
    BufferedWriter writer     = httpResponse.getWriter();
    String         stringBody = httpRequest.getReader().lines().collect(Collectors.joining());
    BodyArgs       bodyArgs   = BodyArgs.builder().build();
    if (!stringBody.isEmpty()) {
      bodyArgs = Config.OBJECT_MAPPER.readValue(stringBody, BodyArgs.class);
    }
    SentenceGenerator sentenceGenerator = new SentenceGenerator(bodyArgs);
    List<Sentence>    result            = sentenceGenerator.generateRandomSentences();
    writer.write(Config.OBJECT_MAPPER.writeValueAsString(result));
    LOGGER.debug("service finished");
  }


}