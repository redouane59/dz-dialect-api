package function.model;

public enum Possession {

  I,
  YOU,
  OTHER

}
