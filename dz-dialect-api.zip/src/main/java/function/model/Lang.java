package function.model;

public enum Lang {
  FR,
  DZ
}
