package function.model.verb;

import function.model.CustomList;
import function.model.Lang;
import function.model.Translation;
import java.util.List;
import lombok.Getter;

@Getter
public enum VerbType {

  STATE(CustomList.of(new Translation(Lang.FR, "dans"), new Translation(Lang.DZ, "fel"))),
  ACTION(CustomList.of(new Translation(Lang.FR, "à"), new Translation(Lang.DZ, "lel")));

  private final CustomList<Translation> placePrepositions;

  VerbType(CustomList<Translation> placePropositions) {
    this.placePrepositions = placePropositions;
  }

  public String getPlacePreposition(Lang lang) {
    return this.getPlacePrepositions().stream().filter(o -> o.getLang() == lang).findAny().orElseThrow().getValue();
  }

  public String getPlacePreposition(Lang lang, String nextNoun) {
    List<String> consonant = List.of("d", "n", "r", "t", "s", "z", "ch"); // @todo fix for ch
    if (consonant.contains(nextNoun.substring(0, 1)) && lang == Lang.DZ) {
      return "fe";
    }
    return placePrepositions.getTranslationValue(lang);
  }

}
