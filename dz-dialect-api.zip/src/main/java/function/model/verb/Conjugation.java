package function.model.verb;

import function.model.CustomList;
import function.model.Person;
import function.model.AbstractWord;
import function.model.Translation;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
public class Conjugation extends AbstractWord {

  private Person person;

  public Conjugation(Person person, Translation fr, Translation dz) {
    super(CustomList.of(fr, dz));
    this.person = person;
  }

}
