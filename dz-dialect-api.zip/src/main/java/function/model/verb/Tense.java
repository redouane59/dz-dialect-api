package function.model.verb;

public enum Tense {
  PAST,
  PRESENT,
  FUTUR
}
