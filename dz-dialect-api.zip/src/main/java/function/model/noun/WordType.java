package function.model.noun;

public enum WordType {
  PLACE,
  ADJECTIVE,
  VERB,
  UNDEFINED
}
