package function.model.noun;

import function.model.Gender;
import function.model.AbstractWord;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Getter
public class Noun extends AbstractWord {

  private boolean singular;
  private Gender  gender;

}
